<?php
// Konfigurasi folder
define('DIR_ADM',           'admin');
define('DIR_APP',           'app');
define('DIR_RES',           'res');
define('DIR_SRC',           'src');

// Konfigurasi Database MySQL
define('DB_HOST',           'localhost');
define('DB_USER',           'root');
define('DB_PASS',           '12345678');
define('DB_NAME',           'others_auto');

// Konfigurasi Date/Time
define('TIMEZONE',          'Asia/Jakarta');