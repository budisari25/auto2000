<?php
// Konfigurasi Version
define('CONF_STRUCTURE',    'AsaMint');
define('CONF_VER',          '2.6');
define('CONF_BUILD',        '0');
define('CONF_RELEASE',      '25.02.19');