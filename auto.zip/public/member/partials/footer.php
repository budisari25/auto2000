<!-- Footer -->
<footer>

	<!-- Copyright -->
	<div class="footer-copyright text-center py-3 mt-5 font-small">&copy; <?=date('Y')?> Created by
		<a href="https://racikproject.com" target="_blank"> RacikID</a>
		<p class="text-center"><small>Version <?=CONF_VER.'.'.CONF_BUILD.' | '.CONF_RELEASE?></small></p>
	</div>

</footer>
<!-- Footer -->