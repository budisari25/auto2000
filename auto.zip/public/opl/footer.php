<!-- footer -->
<footer class="d-flex justify-content-between">     
    <button class="btn btn-primary" id="pause">Pause</button>
    <!-- Info footer -->
    <div class="justify-content-between" id="footer-md"></div>
</footer>
<!-- /.footer -->