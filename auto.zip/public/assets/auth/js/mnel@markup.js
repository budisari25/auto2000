// markup html in javascript
const _markup = `

    	

`;

document.body.innerHTML = _markup;